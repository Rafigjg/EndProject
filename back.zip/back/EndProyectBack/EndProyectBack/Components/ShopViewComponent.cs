﻿using EndProyectBack.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EndProyectBack.Components
{
    public class ShopViewComponent : ViewComponent
    {
        private readonly BoykaDbContext _context;
        public ShopViewComponent(BoykaDbContext context)
        {
            _context = context;
        }
        public async Task<IViewComponentResult> InvokeAsync(int id)
        {
            var menu = await _context.Categoryes.Include("SubCategories").ToListAsync();
            return View(menu);
        }
    }
}
