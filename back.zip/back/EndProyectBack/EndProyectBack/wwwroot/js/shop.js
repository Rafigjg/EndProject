// $(document).ready(function () {
    
//     $('.single-product-wrap').hover(function () {
//         console.log("salam");
//         $('.quick-view-btn').toggleClass('d-block');
//         $('.price-box').toggleClass('d-none');
//         $('.add-to-cart').toggleClass('d-block');
//     });


// });




