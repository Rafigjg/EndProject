﻿using EndProyectBack.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EndProyectBack.ViewModels
{
    public class HomeViewModel
    {
      
        
        public IEnumerable<HomeSliderFirst> HomeSliderFirst { get; set; }
        public IEnumerable<Header> Header { get; set; }
        public IEnumerable<Footer> Footers { get; set; }
        public IEnumerable<DailyDeals> DailyDeals { get; set; }
        public IEnumerable<Product> Products { get; set; }
        public IEnumerable<AboutPhoto> AboutPhotos { get; set; }
        public IEnumerable<AboutTeam> AboutTeams { get; set; }
        public IEnumerable<AboutTextArea> AboutTextAreas { get; set; }
        public IEnumerable<ContactUs> ContactUs { get; set; }
        public IEnumerable<Category> Categories { get; set; }
        public IEnumerable<SubCategory> SubCategories { get; set; }

    }
}
