﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EndProyectBack.Models
{
    public class BoykaDbContext: IdentityDbContext<AppUser>
    {
        //public BoykaDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions) { }

        public BoykaDbContext(DbContextOptions<BoykaDbContext> options) : base(options)
        {

        }
        public DbSet<Header> Headers { get; set; }
        public DbSet<Footer> Footers { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<SubCategory> SubCategoryes { get; set; }
        public DbSet<PhotoAreaFirst> PhotoAreaFirsts { get; set; }
        public DbSet<PhotoAreaSecond> PhotoAreaSeconds { get; set; }
        public DbSet<HomeSliderFirst> HomeSliderFirsts { get; set; }
        public DbSet<DailyDeals> DailyDealss { get; set; }
        public DbSet<ContactUs> ContactUss { get; set; }
        public DbSet<Category> Categoryes { get; set; }
        public DbSet<AboutTextArea> AboutTextAreas { get; set; }
        public DbSet<AboutTeam> AboutTeams { get; set; }
        public DbSet<AboutPhoto> AboutPhotos { get; set; }


    }
}
