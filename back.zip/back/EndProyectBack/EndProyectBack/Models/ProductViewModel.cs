﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EndProyectBack.Models
{
    public class ProductViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public IFormFile Image { get; set; }
        public decimal? OldPrice { get; set; }
        public decimal NewPrice { get; set; }
        public byte? Discount { get; set; }
        [Required, StringLength(800)]
        public string Description { get; set; }
        [Required, StringLength(20)]
        public string Size { get; set; }
        [Required, StringLength(20)]
        public string Color { get; set; }
        [Required]
        public int Quantity { get; set; }
        public SubCategory SubCategory { get; set; }
        public int SubCategoryId { get; set; }
    }
}
