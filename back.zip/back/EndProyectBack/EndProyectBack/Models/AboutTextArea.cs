﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EndProyectBack.Models
{
    public class AboutTextArea
    {
        public int Id { get; set; }
        [Required,StringLength(100)]
        public string Title1 { get; set; }
        [Required, StringLength(1900)]
        public string Title2 { get; set; }
        [Required, StringLength(1900)]
        public string Title3 { get; set; }
    }
}
