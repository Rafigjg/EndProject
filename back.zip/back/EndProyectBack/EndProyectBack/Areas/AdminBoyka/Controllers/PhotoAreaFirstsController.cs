﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EndProyectBack.Models;

namespace EndProyectBack.Areas.AdminBoyka.Controllers
{
    [Area("AdminBoyka")]
    public class PhotoAreaFirstsController : Controller
    {
        private readonly BoykaDbContext _context;

        public PhotoAreaFirstsController(BoykaDbContext context)
        {
            _context = context;
        }

        // GET: AdminBoyka/PhotoAreaFirsts
        public async Task<IActionResult> Index()
        {
            return View(await _context.PhotoAreaFirsts.ToListAsync());
        }

        // GET: AdminBoyka/PhotoAreaFirsts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var photoAreaFirst = await _context.PhotoAreaFirsts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (photoAreaFirst == null)
            {
                return NotFound();
            }

            return View(photoAreaFirst);
        }

        // GET: AdminBoyka/PhotoAreaFirsts/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AdminBoyka/PhotoAreaFirsts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Image")] PhotoAreaFirst photoAreaFirst)
        {
            if (ModelState.IsValid)
            {
                _context.Add(photoAreaFirst);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(photoAreaFirst);
        }

        // GET: AdminBoyka/PhotoAreaFirsts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var photoAreaFirst = await _context.PhotoAreaFirsts.FindAsync(id);
            if (photoAreaFirst == null)
            {
                return NotFound();
            }
            return View(photoAreaFirst);
        }

        // POST: AdminBoyka/PhotoAreaFirsts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Image")] PhotoAreaFirst photoAreaFirst)
        {
            if (id != photoAreaFirst.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(photoAreaFirst);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PhotoAreaFirstExists(photoAreaFirst.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(photoAreaFirst);
        }

        // GET: AdminBoyka/PhotoAreaFirsts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var photoAreaFirst = await _context.PhotoAreaFirsts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (photoAreaFirst == null)
            {
                return NotFound();
            }

            return View(photoAreaFirst);
        }

        // POST: AdminBoyka/PhotoAreaFirsts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var photoAreaFirst = await _context.PhotoAreaFirsts.FindAsync(id);
            _context.PhotoAreaFirsts.Remove(photoAreaFirst);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PhotoAreaFirstExists(int id)
        {
            return _context.PhotoAreaFirsts.Any(e => e.Id == id);
        }
    }
}
