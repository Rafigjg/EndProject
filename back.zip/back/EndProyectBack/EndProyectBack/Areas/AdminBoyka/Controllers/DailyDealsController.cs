﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EndProyectBack.Models;

namespace EndProyectBack.Areas.AdminBoyka.Controllers
{
    [Area("AdminBoyka")]
    public class DailyDealsController : Controller
    {
        private readonly BoykaDbContext _context;

        public DailyDealsController(BoykaDbContext context)
        {
            _context = context;
        }

        // GET: AdminBoyka/DailyDeals
        public async Task<IActionResult> Index()
        {
            return View(await _context.DailyDealss.ToListAsync());
        }

        // GET: AdminBoyka/DailyDeals/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dailyDeals = await _context.DailyDealss
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dailyDeals == null)
            {
                return NotFound();
            }

            return View(dailyDeals);
        }

        // GET: AdminBoyka/DailyDeals/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AdminBoyka/DailyDeals/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Image,Title1,Title2")] DailyDeals dailyDeals)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dailyDeals);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dailyDeals);
        }

        // GET: AdminBoyka/DailyDeals/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dailyDeals = await _context.DailyDealss.FindAsync(id);
            if (dailyDeals == null)
            {
                return NotFound();
            }
            return View(dailyDeals);
        }

        // POST: AdminBoyka/DailyDeals/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Image,Title1,Title2")] DailyDeals dailyDeals)
        {
            if (id != dailyDeals.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dailyDeals);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DailyDealsExists(dailyDeals.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dailyDeals);
        }

        // GET: AdminBoyka/DailyDeals/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dailyDeals = await _context.DailyDealss
                .FirstOrDefaultAsync(m => m.Id == id);
            if (dailyDeals == null)
            {
                return NotFound();
            }

            return View(dailyDeals);
        }

        // POST: AdminBoyka/DailyDeals/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dailyDeals = await _context.DailyDealss.FindAsync(id);
            _context.DailyDealss.Remove(dailyDeals);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DailyDealsExists(int id)
        {
            return _context.DailyDealss.Any(e => e.Id == id);
        }
    }
}
