﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EndProyectBack.Models;

namespace EndProyectBack.Areas.AdminBoyka.Controllers
{
    [Area("AdminBoyka")]
    public class AboutTextAreasController : Controller
    {
        private readonly BoykaDbContext _context;

        public AboutTextAreasController(BoykaDbContext context)
        {
            _context = context;
        }

        // GET: AdminBoyka/AboutTextAreas
        public async Task<IActionResult> Index()
        {
            return View(await _context.AboutTextAreas.ToListAsync());
        }

        // GET: AdminBoyka/AboutTextAreas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aboutTextArea = await _context.AboutTextAreas
                .FirstOrDefaultAsync(m => m.Id == id);
            if (aboutTextArea == null)
            {
                return NotFound();
            }

            return View(aboutTextArea);
        }

        // GET: AdminBoyka/AboutTextAreas/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AdminBoyka/AboutTextAreas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title1,Title2,Title3")] AboutTextArea aboutTextArea)
        {
            if (ModelState.IsValid)
            {
                _context.Add(aboutTextArea);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(aboutTextArea);
        }

        // GET: AdminBoyka/AboutTextAreas/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aboutTextArea = await _context.AboutTextAreas.FindAsync(id);
            if (aboutTextArea == null)
            {
                return NotFound();
            }
            return View(aboutTextArea);
        }

        // POST: AdminBoyka/AboutTextAreas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title1,Title2,Title3")] AboutTextArea aboutTextArea)
        {
            if (id != aboutTextArea.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(aboutTextArea);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AboutTextAreaExists(aboutTextArea.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(aboutTextArea);
        }

        // GET: AdminBoyka/AboutTextAreas/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aboutTextArea = await _context.AboutTextAreas
                .FirstOrDefaultAsync(m => m.Id == id);
            if (aboutTextArea == null)
            {
                return NotFound();
            }

            return View(aboutTextArea);
        }

        // POST: AdminBoyka/AboutTextAreas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var aboutTextArea = await _context.AboutTextAreas.FindAsync(id);
            _context.AboutTextAreas.Remove(aboutTextArea);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AboutTextAreaExists(int id)
        {
            return _context.AboutTextAreas.Any(e => e.Id == id);
        }
    }
}
