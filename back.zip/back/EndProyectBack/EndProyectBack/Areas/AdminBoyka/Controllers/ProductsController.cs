﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EndProyectBack.Models;
using EndProyectBack.Extensions;
using Microsoft.AspNetCore.Hosting;
using static EndProyectBack.Utilities.Utilities;

namespace EndProyectBack.Areas.AdminBoyka.Controllers
{
    [Area("AdminBoyka")]
    public class ProductsController : Controller
    {
        private readonly BoykaDbContext _context;
        private readonly IHostingEnvironment _env;

        public ProductsController(BoykaDbContext context, IHostingEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET: AdminBoyka/Products
        public async Task<IActionResult> Index()
        {
            var boykaDbContext = _context.Products.Include(p => p.SubCategory);
            return View(await boykaDbContext.ToListAsync());
        }

        // GET: AdminBoyka/Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.SubCategory)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: AdminBoyka/Products/Create
        public IActionResult Create()
        {
            ViewData["SubCategoryId"] = new SelectList(_context.SubCategoryes, "Id", "Name");
            return View();
        }

        // POST: AdminBoyka/Products/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("Id,Name,Image,OldPrice,NewPrice,Discount,Description,Size,Color,Quantity,SubCategoryId")] Product product)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(product);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    ViewData["SubCategoryId"] = new SelectList(_context.SubCategoryes, "Id", "Name", product.SubCategoryId);
        //    return View(product);
        //}

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            if (!ModelState.IsValid) return View(product);

            if (product.Photo == null)
            {
                ModelState.AddModelError("Photo", "Photo should be selected");
                return View(product);
            }

            if (!product.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Photo is not valid");
                return View(product);
            }

            product.Image = await product.Photo.SaveFileAsync(_env.WebRootPath, "product");

            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: AdminBoyka/Products/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            ViewData["SubCategoryId"] = new SelectList(_context.SubCategoryes, "Id", "Name", product.SubCategoryId);
            return View(product);
        }

        // POST: AdminBoyka/Products/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            if (!ModelState.IsValid) return View(product);

            Product productFromDb = await _context.Products.FindAsync(id);

            if(productFromDb == null)
            {
                return NotFound();
            }

            if (product.Photo != null)
            {
                if (product.Photo.IsImage())
                {
                    //Remove old image
                    RemoveFile(productFromDb.Image, "product", _env.WebRootPath);

                    //Save new image
                    productFromDb.Image = await product.Photo.SaveFileAsync(_env.WebRootPath, "product");
                }
                else
                {
                    ModelState.AddModelError("Photo", "Photo is invalid");
                    return View(product);
                }
            }

            productFromDb.Name = product.Name;
            productFromDb.NewPrice = product.NewPrice;
            productFromDb.OldPrice = product.OldPrice;
            productFromDb.Quantity = product.Quantity;
            productFromDb.Size = product.Size;
            productFromDb.SubCategoryId= product.SubCategoryId;
            productFromDb.Discount = product.Discount;



            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: AdminBoyka/Products/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.SubCategory)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: AdminBoyka/Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _context.Products.FindAsync(id);
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.Id == id);
        }
    }
}
