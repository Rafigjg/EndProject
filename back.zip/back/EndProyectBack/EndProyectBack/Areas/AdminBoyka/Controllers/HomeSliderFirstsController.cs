﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EndProyectBack.Models;

namespace EndProyectBack.Areas.AdminBoyka.Controllers
{
    [Area("AdminBoyka")]
    public class HomeSliderFirstsController : Controller
    {
        private readonly BoykaDbContext _context;

        public HomeSliderFirstsController(BoykaDbContext context)
        {
            _context = context;
        }

        // GET: AdminBoyka/HomeSliderFirsts
        public async Task<IActionResult> Index()
        {
            return View(await _context.HomeSliderFirsts.ToListAsync());
        }

        // GET: AdminBoyka/HomeSliderFirsts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var homeSliderFirst = await _context.HomeSliderFirsts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (homeSliderFirst == null)
            {
                return NotFound();
            }

            return View(homeSliderFirst);
        }

        // GET: AdminBoyka/HomeSliderFirsts/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AdminBoyka/HomeSliderFirsts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Image,Title1,Title2")] HomeSliderFirst homeSliderFirst)
        {
            if (ModelState.IsValid)
            {
                _context.Add(homeSliderFirst);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(homeSliderFirst);
        }

        // GET: AdminBoyka/HomeSliderFirsts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var homeSliderFirst = await _context.HomeSliderFirsts.FindAsync(id);
            if (homeSliderFirst == null)
            {
                return NotFound();
            }
            return View(homeSliderFirst);
        }

        // POST: AdminBoyka/HomeSliderFirsts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Image,Title1,Title2")] HomeSliderFirst homeSliderFirst)
        {
            if (id != homeSliderFirst.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(homeSliderFirst);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HomeSliderFirstExists(homeSliderFirst.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(homeSliderFirst);
        }

        // GET: AdminBoyka/HomeSliderFirsts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var homeSliderFirst = await _context.HomeSliderFirsts
                .FirstOrDefaultAsync(m => m.Id == id);
            if (homeSliderFirst == null)
            {
                return NotFound();
            }

            return View(homeSliderFirst);
        }

        // POST: AdminBoyka/HomeSliderFirsts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var homeSliderFirst = await _context.HomeSliderFirsts.FindAsync(id);
            _context.HomeSliderFirsts.Remove(homeSliderFirst);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HomeSliderFirstExists(int id)
        {
            return _context.HomeSliderFirsts.Any(e => e.Id == id);
        }
    }
}
