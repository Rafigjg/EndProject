﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EndProyectBack.Models;

namespace EndProyectBack.Areas.AdminBoyka.Controllers
{
    [Area("AdminBoyka")]
    public class AboutTeamsController : Controller
    {
        private readonly BoykaDbContext _context;

        public AboutTeamsController(BoykaDbContext context)
        {
            _context = context;
        }

        // GET: AdminBoyka/AboutTeams
        public async Task<IActionResult> Index()
        {
            return View(await _context.AboutTeams.ToListAsync());
        }

        // GET: AdminBoyka/AboutTeams/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aboutTeam = await _context.AboutTeams
                .FirstOrDefaultAsync(m => m.Id == id);
            if (aboutTeam == null)
            {
                return NotFound();
            }

            return View(aboutTeam);
        }

        // GET: AdminBoyka/AboutTeams/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: AdminBoyka/AboutTeams/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Image,Name,Duty")] AboutTeam aboutTeam)
        {
            if (ModelState.IsValid)
            {
                _context.Add(aboutTeam);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(aboutTeam);
        }

        // GET: AdminBoyka/AboutTeams/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aboutTeam = await _context.AboutTeams.FindAsync(id);
            if (aboutTeam == null)
            {
                return NotFound();
            }
            return View(aboutTeam);
        }

        // POST: AdminBoyka/AboutTeams/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Image,Name,Duty")] AboutTeam aboutTeam)
        {
            if (id != aboutTeam.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(aboutTeam);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AboutTeamExists(aboutTeam.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(aboutTeam);
        }

        // GET: AdminBoyka/AboutTeams/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var aboutTeam = await _context.AboutTeams
                .FirstOrDefaultAsync(m => m.Id == id);
            if (aboutTeam == null)
            {
                return NotFound();
            }

            return View(aboutTeam);
        }

        // POST: AdminBoyka/AboutTeams/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var aboutTeam = await _context.AboutTeams.FindAsync(id);
            _context.AboutTeams.Remove(aboutTeam);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AboutTeamExists(int id)
        {
            return _context.AboutTeams.Any(e => e.Id == id);
        }
    }
}
