﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using EndProyectBack.Models;
using EndProyectBack.ViewModels;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace EndProyectBack.Controllers
{
    public class HomeController : Controller
    {
        public BoykaDbContext _context;
        public HomeController(BoykaDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            //Response.Cookies.Append("Product", "Boyka", new CookieOptions { MaxAge = TimeSpan.FromMinutes(20) });
            //HttpContext.Session.SetString("Product","Boyka");

            HomeViewModel vm = new HomeViewModel
            {
                HomeSliderFirst = _context.HomeSliderFirsts,
                Header = _context.Headers,
                Footers =_context.Footers,
                DailyDeals =_context.DailyDealss

            };
            return View(vm);
        }
        
        public async Task<IActionResult> AddBAsket(int id)
        {
            Product product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            List<BasketProVM> list;
            string currentBasket = HttpContext.Session.GetString("basket");
            if(currentBasket==null)
            {
                list = new List<BasketProVM>();
            }
            else
            {
                list = JsonConvert.DeserializeObject<List<BasketProVM>>(currentBasket);
            }
            var chekPro = list.FirstOrDefault(p => p.Id == id);
            if (chekPro == null)
            {
                BasketProVM basketPro = new BasketProVM
                {
                    Id = product.Id,
                    Name = product.Name,
                    Image = product.Image,
                    NewPrice = product.NewPrice,
                    Count = 1
                };
                list.Add(basketPro);
            }
            else
            {
                chekPro.Count += 1;
            }
            
            string basket = JsonConvert.SerializeObject(list);
            HttpContext.Session.SetString("basket",basket);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Basket()
        {
            //string cookie = Request.Cookies["Product"];
            //string session = HttpContext.Session.GetString("Product");
            //return Content(HttpContext.Session.GetString("basket"));
            string basket = HttpContext.Session.GetString("basket");
           
            return RedirectToAction("Index", "cart");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
