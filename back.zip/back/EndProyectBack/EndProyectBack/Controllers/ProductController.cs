﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EndProyectBack.Models;
using EndProyectBack.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace EndProyectBack.Controllers
{
    public class ProductController : Controller
    {
        public BoykaDbContext _context;
        public ProductController(BoykaDbContext context)
        {
            _context = context;
        }
        public IActionResult Index(int id)
        {
            var products = _context.Products.Where(x => x.Id == id);
            ViewBag.Header = _context.Headers.Select(x=>x.Email).ToList();
            return View(products);
        }
    }
}