﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EndProyectBack.Models;
using EndProyectBack.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace EndProyectBack.Controllers
{
    public class LoginRegisterController : Controller
    {
        public BoykaDbContext _context;
        public LoginRegisterController(BoykaDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            HomeViewModel vm = new HomeViewModel
            {
                HomeSliderFirst = _context.HomeSliderFirsts,
                Header = _context.Headers,
                Footers = _context.Footers,
                DailyDeals = _context.DailyDealss,
                Products = _context.Products,
                AboutPhotos = _context.AboutPhotos,
                AboutTeams = _context.AboutTeams,
                AboutTextAreas = _context.AboutTextAreas,
                ContactUs = _context.ContactUss

            };
            return View(vm);
        }
    }
}