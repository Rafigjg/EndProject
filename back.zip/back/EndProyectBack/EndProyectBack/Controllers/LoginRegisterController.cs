﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EndProyectBack.Models;
using EndProyectBack.Role;
using EndProyectBack.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace EndProyectBack.Controllers
{
    public class LoginRegisterController : Controller
    {
        public BoykaDbContext _context;
        private UserManager<AppUser> userManager;
        private RoleManager<IdentityRole> roleManager;
        public LoginRegisterController(BoykaDbContext context, UserManager<AppUser> _userManager, RoleManager<IdentityRole> _roleManager)
        {
            _context = context;
            userManager = _userManager;
            roleManager = _roleManager;
        }
        public async Task RoleSeed()
        {
            if (!await roleManager.RoleExistsAsync(UserRole.Roles.Admin.ToString()))
                await roleManager.CreateAsync(new IdentityRole(UserRole.Roles.Admin.ToString())); 
        }
        public IActionResult Index()
        {
            return View();
        }

        //[HttpPost, ValidateAntiForgeryToken]
        //public async Task<IActionResult> Index(RegisterVM registerVM)
        //{
        //    if (!ModelState.IsValid) return NotFound();

        //    AppUser appUser = new AppUser
        //    {
        //        UserName = registerVM.UserName,
        //        Email = registerVM.Email,
        //    };

        //    IdentityResult identityResult = await userManager.CreateAsync(appUser, registerVM.Password);

        //    if (!identityResult.Succeeded)
        //    {
        //        foreach (var error in identityResult.Errors)
        //        {
        //            ModelState.AddModelError("", error.Description);
        //        }
        //        return View(registerVM);
        //    }

        //    //await userManager.AddToRoleAsync(appUser, UserRole.Roles.User.ToString());
        //    return View();
        //}
    }
}