﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EndProyectBack.Models;
using EndProyectBack.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace EndProyectBack.Controllers
{
    public class CartController : Controller
    {
        public BoykaDbContext _context;
        public CartController(BoykaDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            HomeViewModel vm = new HomeViewModel
            {
                HomeSliderFirst = _context.HomeSliderFirsts,
                Header = _context.Headers,
                Footers = _context.Footers,
                DailyDeals = _context.DailyDealss,
                Products = _context.Products,
                Categories = _context.Categoryes,
                SubCategories = _context.SubCategoryes

            };
            ViewBag.b = JsonConvert.DeserializeObject<List<BasketProVM>>(HttpContext.Session.GetString("basket"));
            return View(vm);
        }
       
    }
}