﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EndProyectBack.Models;
using EndProyectBack.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace EndProyectBack.Controllers
{
    public class ShopController : Controller
    {
        public BoykaDbContext _context;
        public ShopController(BoykaDbContext context)
        {
            _context = context;
        }
        public IActionResult Index(int Id)
        {
            
            HomeViewModel vm = new HomeViewModel
            {
                HomeSliderFirst = _context.HomeSliderFirsts,
                Header = _context.Headers,
                Footers = _context.Footers,
                DailyDeals = _context.DailyDealss,
                Products =_context.Products,
                Categories=_context.Categoryes,
                SubCategories=_context.SubCategoryes

            };
            return View(vm);
        }
    }
}